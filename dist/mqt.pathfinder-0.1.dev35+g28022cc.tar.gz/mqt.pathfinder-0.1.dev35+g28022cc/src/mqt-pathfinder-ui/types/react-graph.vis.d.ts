declare module 'react-graph-vis' {
    export default class Graph extends React.Component<any, any> {};
}
